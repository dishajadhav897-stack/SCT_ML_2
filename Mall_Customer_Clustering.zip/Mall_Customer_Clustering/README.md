Task 02: Customer Segmentation using K-Means Clustering

Objective:
To group retail store customers based on purchase behavior using K-Means clustering.

Approach:
- Customer data was loaded and relevant features were selected.
- K-Means clustering was applied to segment customers.
- Clusters were visualized using a scatter plot.

Technologies Used:
- Python
- Pandas
- Scikit-learn
- Matplotlib
- PyCharm IDE

Result:
The model successfully grouped customers into distinct segments based on income and spending patterns.
